package main;

import game.GameInit;

public class Run {

	public static void main(String[] args) {
		System.out.println("Welcome to DOWN with the QUEEN!!! \n");

		// Create instance of game object
		GameInit gameInstance = new GameInit();
		gameInstance.gameInit();
		
		
	}
	
}
