package data;

public class Game {

}
